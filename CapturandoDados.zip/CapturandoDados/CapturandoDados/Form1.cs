﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapturandoDados
{
    public partial class FmrDados : Form
    {
        public FmrDados()
        {
            InitializeComponent();
        }

        private void txtBoleano_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Clicou no botão!");
        }

        private void label1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Abriu formulário!");
        }

        private void lblBoleano_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Alterou texto!");
        }

        private void btnEnviar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Clicou na label!");
        }
    }
}
